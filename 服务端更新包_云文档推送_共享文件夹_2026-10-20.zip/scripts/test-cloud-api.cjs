// 飞书云文档传输 API 冒烟测试（不联网上传、不需要有效授权）。
// 覆盖：状态接口形状 / 未授权访问 / 参数校验 / 回调 state 校验。
// 注意：本机可能已存在 server/feishuConfig.json（含真实凭证），所以断言只校验「形状与状态码」，
// 不断言 configured 一定是 false。
// 运行：node scripts/test-cloud-api.cjs
'use strict';
const express = require('express');
const http = require('http');

const attach = require('../server/feishuCloudApi.js');

const app = express();
attach(app);
const server = http.createServer(app);

const PORT = 41873;
let passed = 0;
let failed = 0;

function check(name, cond, extra) {
  if (cond) {
    passed++;
    console.log(`  ok   ${name}`);
  } else {
    failed++;
    console.log(`  FAIL ${name}${extra ? ' — ' + extra : ''}`);
  }
}

async function post(path, body, headers) {
  const res = await fetch(`http://127.0.0.1:${PORT}${path}`, { method: 'POST', headers, body });
  let json = null;
  try { json = await res.json(); } catch (e) { /* 可能非 JSON */ }
  return { status: res.status, json };
}

async function get(path) {
  const res = await fetch(`http://127.0.0.1:${PORT}${path}`);
  let json = null;
  try { json = await res.json(); } catch (e) { /* 可能非 JSON */ }
  return { status: res.status, json };
}

(async () => {
  await new Promise((r) => server.listen(PORT, '127.0.0.1', r));
  console.log('飞书云文档传输 API 冒烟测试');

  // 1) 状态接口：形状正确，授权相关字段是布尔
  const st = await get('/api/cloud/status');
  check('GET /api/cloud/status 返回 200', st.status === 200, `status=${st.status}`);
  check('configured 是布尔值', typeof st.json?.configured === 'boolean', JSON.stringify(st.json));
  check('authorized 是布尔值', typeof st.json?.authorized === 'boolean');
  check('authExpired 是布尔值', typeof st.json?.authExpired === 'boolean');
  check('有 webhookConfigured 字段', typeof st.json?.webhookConfigured === 'boolean');
  check('有 webhookEnabled 字段', typeof st.json?.webhookEnabled === 'boolean');
  check('注册状态自洽（authorized 与 authExpired 不同时为真）',
    !(st.json?.authorized === true && st.json?.authExpired === true), JSON.stringify(st.json));
  if (!st.json?.configured) {
    check('未配置时带 hint 提示', typeof st.json?.hint === 'string' && st.json.hint.length > 0);
  }

  // 2) 授权链接：已配置返回 200 + authorizeUrl；未配置返回 400
  const start = await post('/api/cloud/oauth/start');
  if (st.json?.configured) {
    check('POST /api/cloud/oauth/start 已配置时返回授权链接',
      start.status === 200 && typeof start.json?.authorizeUrl === 'string' && start.json.authorizeUrl.includes('client_id'),
      JSON.stringify(start.json));
  } else {
    check('POST /api/cloud/oauth/start 未配置时 400', start.status === 400, `status=${start.status}`);
  }

  // 3) 列文件夹：未授权应为 4xx；已授权则 200（本测试只读，不会写盘）
  const list = await get('/api/cloud/folders');
  if (st.json?.authorized) {
    check('GET /api/cloud/folders 已授权时 200 且返回 folders 数组',
      list.status === 200 && Array.isArray(list.json?.folders), `status=${list.status}`);
  } else {
    check('GET /api/cloud/folders 未授权时 4xx', list.status >= 400 && list.status < 500,
      `status=${list.status} ${JSON.stringify(list.json)}`);
  }

  // 4) 上传参数校验（都在触碰网络之前）
  const empty = await post('/api/cloud/upload', Buffer.alloc(0), { 'Content-Type': 'application/octet-stream' });
  check('空 body 上传 → 400 内容为空', empty.status === 400 && /为空/.test(empty.json?.error || ''), JSON.stringify(empty.json));

  const fakeDocx = Buffer.concat([Buffer.from([0x50, 0x4b, 0x03, 0x04]), Buffer.alloc(64)]);
  const noName = await post('/api/cloud/upload', fakeDocx, { 'Content-Type': 'application/octet-stream' });
  check('缺 file_name → 400 缺少文件名', noName.status === 400 && /文件名/.test(noName.json?.error || ''), JSON.stringify(noName.json));

  const badExt = await post('/api/cloud/upload?file_name=a.pdf', fakeDocx, { 'Content-Type': 'application/octet-stream' });
  check('非 docx/xlsx → 400 仅支持', badExt.status === 400 && /仅支持/.test(badExt.json?.error || ''), JSON.stringify(badExt.json));

  // 参数合法但未授权 → 4xx。
  // ⚠️ 已授权时必须跳过：这条会真的往云盘写入一个文件，测试不能污染用户数据。
  if (!st.json?.authorized) {
    const noAuth = await post('/api/cloud/upload?file_name=a.docx&folder_token=', fakeDocx, { 'Content-Type': 'application/octet-stream' });
    check('参数合法但未授权 → 4xx', noAuth.status >= 400 && noAuth.status < 500, JSON.stringify(noAuth.json));
  } else {
    console.log('  skip  参数合法但未授权（当前已授权，跳过以免真实写入云盘）');
  }

  // 5) verify 未授权时应 4xx
  const verify = await post('/api/cloud/verify', JSON.stringify({ folderToken: 'fldfake' }), { 'Content-Type': 'application/json' });
  check('POST /api/cloud/verify 未授权时 4xx', verify.status >= 400 && verify.status < 500, `status=${verify.status}`);

  // 6) callback 带非法 state 应返回提示页而不是崩溃
  const cb = await fetch(`http://127.0.0.1:${PORT}/api/cloud/oauth/callback?code=x&state=bad`);
  const html = await cb.text();
  check('callback 非法 state → 200 提示页', cb.status === 200 && /授权校验失败/.test(html), `status=${cb.status}`);

  // 7) 请求体模板渲染：占位符替换 + JSON 转义 + 未知变量保留
  const renderBodyTemplate = attach.renderBodyTemplate;
  const DEFAULT_BODY_TEMPLATE = attach.DEFAULT_BODY_TEMPLATE;
  const trickyName = '含"引号"和\\反斜杠.docx';
  const rendered = renderBodyTemplate(DEFAULT_BODY_TEMPLATE, {
    fileName: trickyName,
    pusher: '祝芸',
    text: '祝芸 推送了「含"引号"」到飞书云盘',
    pushedAt: '2026-10-20 15:00:00',
    fileUrl: 'https://x/y',
    folderName: 'A/B',
  });
  let parsed = null;
  try { parsed = JSON.parse(rendered); } catch (e) { /* 下面断言会失败 */ }
  check('模板渲染后是合法 JSON（含引号/反斜杠）', !!parsed, rendered.slice(0, 200));
  check('JSON 转义正确：fileName 原值可还原', parsed && parsed.fileName === trickyName, parsed && parsed.fileName);
  check('默认模板字段齐全', parsed && ['fileName', 'pusher', 'text', 'pushedAt', 'fileUrl', 'folderName'].every((k) => k in parsed));

  const unknownVar = renderBodyTemplate('{"a":"{{nope}}"}', {});
  check('未知变量原样保留', unknownVar.includes('{{nope}}'), unknownVar);

  // 8) 按多维表格读取配置：不存在的 baseId 不应报错，且 webhookConfigured=false
  const cfgRes = await get('/api/cloud/status?base_id=__nonexistent_base__');
  check('status 支持 base_id，未单独配置时 webhookConfigured=false',
    cfgRes.status === 200 && cfgRes.json?.webhookConfigured === false, JSON.stringify(cfgRes.json));
  check('status 下发默认模板与变量清单',
    typeof cfgRes.json?.defaultBodyTemplate === 'string' && Array.isArray(cfgRes.json?.templateVars));

  // 9) 默认不启用：未配置的多维表格不发通知
  const resolved = attach.resolveWebhookConfig('__nonexistent_base__');
  check('未配置时 enabled=false（默认不启用）', resolved.enabled === false, JSON.stringify(resolved));
  check('未配置时 active=false 且地址为空', resolved.active === false && resolved.webhookUrl === '');

  // 未启用时不发请求（也不会因为没地址而误报成功）
  const skipped = await attach.sendAutomationWebhook({
    baseId: '__nonexistent_base__', fileName: 'a.docx', pusher: '张三',
  });
  check('未启用时通知被跳过（reason=disabled）',
    skipped.skipped === true && skipped.reason === 'disabled', JSON.stringify(skipped));

  // 10) 共享文件夹：链接/token 解析
  const parseFolderRef = attach.parseFolderRef;
  check('解析 /drive/folder/<token>',
    parseFolderRef('https://a.feishu.cn/drive/folder/ABCDEFGH12345678') === 'ABCDEFGH12345678');
  check('解析 /drive/shared/folder/<token>',
    parseFolderRef('https://a.feishu.cn/drive/shared/folder/ABCDEFGH12345678') === 'ABCDEFGH12345678');
  check('解析纯 token', parseFolderRef('ABCDEFGH12345678') === 'ABCDEFGH12345678');
  check('无法识别的短串返回空', parseFolderRef('abc') === '');

  const badRef = await get('/api/cloud/folder-meta?ref=abc');
  check('folder-meta 无法识别时 400 并给出用法提示',
    badRef.status === 400 && /无法识别文件夹/.test(badRef.json?.error || ''), JSON.stringify(badRef.json));

  // 已授权时用真实文件夹验证解析链路（只读）
  if (st.json?.authorized) {
    const rootList = await get('/api/cloud/folders');
    const first = rootList.json?.folders?.[0];
    if (first) {
      const okRef = await get(
        '/api/cloud/folder-meta?ref=' + encodeURIComponent(`https://x.feishu.cn/drive/folder/${first.token}`)
      );
      check('folder-meta 能从链接解析出真实文件夹名',
        okRef.status === 200 && okRef.json?.folderToken === first.token && !!okRef.json?.name,
        JSON.stringify(okRef.json));
    }
  } else {
    console.log('  skip  folder-meta 真实解析（当前未授权）');
  }

  server.close();
  console.log(`\n通过 ${passed} / ${passed + failed}`);
  process.exit(failed ? 1 : 0);
})().catch((e) => {
  console.error('测试脚本异常：', e);
  server.close();
  process.exit(1);
});
