// 两层嵌套循环 + 循环内合并字段 端到端验证
//   A) 真实 .docx 模板（微生物检验）：{#外层}{#内层}…{/内层}{/外层} + 行内 {{A}{B}}
//   B) dataBuilder：mock 表结构，验证嵌套关联字段按模板循环字段展开
// 运行：node scripts/test-nested-loop.cjs
// 模板可用环境变量覆盖：DOCX_TEMPLATE=...
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const PizZip = require(path.join(ROOT, 'node_modules', 'pizzip'));
const ts = require(path.join(ROOT, 'node_modules', 'typescript'));

// ---------- 迷你加载器：把 src/*.ts 转成 CJS 后 require ----------
const cache = {};
const SDK_STUB = {
  FieldType: { SingleLink: 18, DuplexLink: 21, Attachment: 17, Checkbox: 7, Text: 1 },
  bitable: { base: { getTableById: async (id) => MOCK_TABLES[id] } },
};
let MOCK_TABLES = {};

function compile(rel) {
  let source = fs.readFileSync(path.resolve(ROOT, 'src', rel), 'utf8');
  source = source.replace(/import\s+type\s+[\s\S]*?;/g, '');
  return ts.transpileModule(source, {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2019 },
  }).outputText;
}
function load(rel) {
  if (cache[rel]) return cache[rel];
  const mod = { exports: {} };
  new Function('module', 'exports', 'require', compile(rel))(mod, mod.exports, (id) => {
    if (id === 'pizzip') return PizZip;
    if (id === 'docxtemplater') return require(path.join(ROOT, 'node_modules', 'docxtemplater'));
    if (id === '@lark-base-open/js-sdk') return SDK_STUB;
    if (id.startsWith('./') || id.startsWith('../')) {
      const dep = path.normalize(path.join(path.dirname(rel), `${id}.ts`)).replace(/\\/g, '/');
      return load(dep);
    }
    return require(id);
  });
  cache[rel] = mod.exports;
  return mod.exports;
}

// ---------- 断言 ----------
let pass = 0, fail = 0;
function assert(name, cond, extra) {
  if (cond) { pass++; console.log('  \u2713', name); }
  else { fail++; console.log('  \u2717', name, extra === undefined ? '' : `\u2192 ${extra}`); }
}
function xmlBalanced(xml) {
  const stack = [];
  const re = /<(\/?)([A-Za-z_][\w:.-]*)((?:"[^"]*"|'[^']*'|[^>"'])*?)(\/?)>/g;
  let m;
  while ((m = re.exec(xml)) !== null) {
    if (m[4]) continue;
    if (m[1]) { if (stack.pop() !== m[2]) return false; } else stack.push(m[2]);
  }
  return stack.length === 0;
}

// 把 document.xml 里的表格拆成「行 → 单元格文本」，便于按行断言某一列
function unesc(s) {
  return String(s).replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&');
}
function tableRows(xml) {
  const rows = [];
  const trRe = /<w:tr\b[^>]*>([\s\S]*?)<\/w:tr>/g;
  let m;
  while ((m = trRe.exec(xml)) !== null) {
    const cells = [];
    const tcRe = /<w:tc\b[^>]*>([\s\S]*?)<\/w:tc>/g;
    let c;
    while ((c = tcRe.exec(m[1])) !== null) {
      cells.push(unesc(c[1].replace(/<[^>]+>/g, '')).trim());
    }
    rows.push(cells);
  }
  return rows;
}

// ---------- 找模板 ----------
function findTemplate() {
  const env = process.env.DOCX_TEMPLATE;
  if (env && fs.existsSync(env)) return env;
  const fixed = 'D:/下载/微生物检验 v1-测试模版.docx';
  if (fs.existsSync(fixed)) return fixed;
  const base = path.join(ROOT, 'templates');
  for (const dir of fs.existsSync(base) ? fs.readdirSync(base) : []) {
    const full = path.join(base, dir);
    if (!fs.statSync(full).isDirectory()) continue;
    const hit = fs.readdirSync(full).find((f) => /微生物.*\.docx$/i.test(f));
    if (hit) return path.join(full, hit);
  }
  return null;
}

const { fillTemplate } = load('services/docxFill.ts');
const { makeMergeResolver } = load('services/mergeField.ts');
const { detectTemplateMerges, detectTemplateLoops } = load('services/mergeDetect.ts');
const { buildPrintData } = load('services/dataBuilder.ts');

(async () => {
  // ======================================================================
  // A) 真实模板：两层循环 + 行内合并字段
  // ======================================================================
  const tplPath = findTemplate();
  console.log('\n[A] 真实 docx 模板嵌套循环');
  if (!tplPath) {
    console.log('  - 未找到模板，跳过（可用 DOCX_TEMPLATE= 指定）');
  } else {
    console.log('  模板：', tplPath);
    const buf = fs.readFileSync(tplPath);
    const ab = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);

    const loops = detectTemplateLoops(ab, path.basename(tplPath));
    assert('检测到两个循环字段', loops.length === 2 && loops.indexOf('F_key微检市场需求表') >= 0
      && loops.indexOf('菌落总数数据表') >= 0, JSON.stringify(loops));

    const hits = detectTemplateMerges(ab, path.basename(tplPath));
    assert('检测到 2 个合并字段', hits.length === 2, JSON.stringify(hits.map((h) => h.signature)));

    // 数据：外层 2 条（内层分别 2 条 / 1 条），模拟子表里的关联字段
    const data = {
      单号: 'NO-TEST',
      样品名称: '顶层样品名',
      F_key微检市场需求表: [
        {
          菌落总数数据表: [
            { 样品名称: 'A1', 细菌数量: '2.2', 细菌乘方v2: '3', 真菌数量: '1.1', 真菌乘方v2: '4' },
            { 样品名称: 'A2', 细菌数量: '3.3', 细菌乘方v2: '5', 真菌数量: '2.2', 真菌乘方v2: '6' },
          ],
        },
        {
          菌落总数数据表: [
            // 条件不满足 → 走 fallback '<10'
            { 样品名称: 'B1', 细菌数量: '0', 细菌乘方v2: '0', 真菌数量: '9.9', 真菌乘方v2: '2' },
          ],
        },
      ],
      菌落总数数据表: [
        { 序号: 1, 样品名称: 'TOP1', 细菌数量: '5.5', 细菌乘方v2: '7' },
      ],
    };

    // 与 PrintTab 完全一致的取值口径 + 线上保存的规则（科学计数法 / 条件 fallback）
    const rules = {
      '细菌数量|细菌乘方v2': {
        join: 'and',
        conditions: [{ field: '细菌数量', op: 'gt', value: '0' }],
        output: { mode: 'scientific', separator: '', superscript: true, times: '×10', precision: null, fallback: '<10' },
      },
      '真菌数量|真菌乘方v2': {
        join: 'and', conditions: [],
        output: { mode: 'scientific', separator: '', superscript: true, times: '×10', precision: null, fallback: '' },
      },
    };
    const resolve = makeMergeResolver(rules, (field, scope) => {
      const v = scope && scope[field] != null ? scope[field] : data[field];
      return v == null || Array.isArray(v) ? '' : String(v);
    });

    const blob = fillTemplate(ab, data, { resolve });
    const out = new PizZip(await blob.arrayBuffer());
    const xml = out.file('word/document.xml').asText();
    // XML 实体要还原：fallback '<10' 在 XML 里是 &lt;10
    const text = xml.replace(/<[^>]+>/g, '')
      .replace(/&lt;/g, '<').replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&');
    // 「备注」之前是检测结果表区域，之后是模板里那行「全字段罗列」的测试行
    const resultArea = text.slice(0, text.indexOf('备 注(Remarks)') >= 0
      ? text.indexOf('备 注(Remarks)') : text.indexOf('备 注'));

    assert('内层 3 行全部渲染', /A1/.test(text) && /A2/.test(text) && /B1/.test(text));
    assert('外层第 1 行：2.2×10³（取行内 细菌数量|细菌乘方v2）', text.includes('2.2×10³'), text.slice(0, 200));
    assert('外层第 1 行第 2 条：3.3×10⁵', text.includes('3.3×10⁵'));
    assert('外层第 2 行：9.9×10²', text.includes('9.9×10²'));
    assert('条件不满足走 fallback <10', text.includes('<10'));
    assert('行内合并字段各取各行（非顶层统一值）',
      text.includes('1.1×10⁴') && text.includes('2.2×10⁶') && text.includes('9.9×10²'));
    assert('无残留复合占位符', !text.includes('{{') && !text.includes('}}{'));
    assert('无残留内部标签 __MERGE', !text.includes('__MERGE'));
    assert('结果表区域无 [object Object]', !resultArea.includes('[object Object]'), resultArea.slice(0, 160));
    assert('顶层单字段仍正常填充', text.includes('NO-TEST'));
    assert('输出 XML 良构', xmlBalanced(xml) === true);

    // 对照：不传合并配置时，{{A}{B}} 会被 docxtemplater 当成重复开标签而报错，
    // 这正是必须有合并字段配置的原因（顺带屏蔽引擎的错误日志，保持输出干净）
    let threw = false;
    const origLog = console.log;
    const origError = console.error;
    console.log = () => {};
    console.error = () => {};
    try {
      await fillTemplate(ab, data, undefined).arrayBuffer();
    } catch (e) {
      threw = true;
    } finally {
      console.log = origLog;
      console.error = origError;
    }
    assert('对照：不传合并配置时模板报重复开标签（故必须走合并配置）', threw);
  }

  // ======================================================================
  // B) dataBuilder：嵌套关联字段按模板循环字段展开
  // ======================================================================
  console.log('\n[B] dataBuilder 两层展开');
  const linkCell = (ids, tableId, text) => ({ recordIds: ids, tableId, text });
  function makeTable(metas, cells, strings) {
    return {
      getFieldMetaList: async () => metas,
      getCellValue: async (fid, rid) => cells[fid] && cells[fid][rid],
      getCellString: async (fid, rid) => {
        const v = strings[fid] && strings[fid][rid];
        if (v !== undefined) return v;
        const c = cells[fid] && cells[fid][rid];
        return c && typeof c.text === 'string' ? c.text : '';
      },
    };
  }
  const F_OUT = { id: 'fOut', type: 18, name: 'F_key微检市场需求表', property: { tableId: 'tblMarket' } };
  const F_NO = { id: 'fNo', type: 1, name: '单号' };
  MOCK_TABLES = {
    tblMain: makeTable([F_OUT, F_NO], { fOut: { r1: linkCell(['m1', 'm2'], 'tblMarket', 'M1,M2') } }, { fNo: { r1: 'NO-1' } }),
    tblMarket: makeTable(
      [{ id: 'mB', type: 18, name: '菌落总数数据表', property: { tableId: 'tblBact' } }],
      { mB: { m1: linkCell(['b1', 'b2'], 'tblBact', 'A1,A2'), m2: linkCell(['b3'], 'tblBact', 'B1') } },
      {}
    ),
    tblBact: makeTable(
      [{ id: 'k1', type: 1, name: '样品名称' }, { id: 'k2', type: 2, name: '细菌数量' }],
      {},
      { k1: { b1: 'A1', b2: 'A2', b3: 'B1' }, k2: { b1: '2.2', b2: '3.3', b3: '9.9' } }
    ),
  };

  // 传 loopFields（新版前端行为）：内层关联字段展开成数组
  const r1 = await buildPrintData(MOCK_TABLES.tblMain, '主表', [F_OUT, F_NO], 'r1',
    { loopFields: ['F_key微检市场需求表', '菌落总数数据表'] });
  const outer = r1.data['F_key微检市场需求表'];
  assert('外层展开 2 条', Array.isArray(outer) && outer.length === 2);
  assert('外层保留 _文本 汇总', r1.data['F_key微检市场需求表_文本'] === 'M1,M2');
  assert('外层行序号 1/2', outer[0].序号 === 1 && outer[1].序号 === 2);
  assert('内层展开为数组（2 条）', Array.isArray(outer[0]['菌落总数数据表']) && outer[0]['菌落总数数据表'].length === 2);
  assert('内层字段值正确', outer[0]['菌落总数数据表'][0]['样品名称'] === 'A1'
    && outer[0]['菌落总数数据表'][0]['细菌数量'] === '2.2');
  assert('内层行号从 1 重新计数', outer[0]['菌落总数数据表'][0].序号 === 1);
  assert('内层保留 _文本 汇总', outer[0]['菌落总数数据表_文本'] === 'A1,A2');
  assert('内层条数各按各的外层行走', outer[1]['菌落总数数据表'].length === 1);
  assert('普通字段不受影响', r1.data['单号'] === 'NO-1');

  // 不传 loopFields（旧调用方）：保持只展开一层，内层仍是汇总文本
  const r2 = await buildPrintData(MOCK_TABLES.tblMain, '主表', [F_OUT, F_NO], 'r1');
  const outer2 = r2.data['F_key微检市场需求表'];
  assert('不传 loopFields → 内层保持汇总文本（旧行为不变）',
    outer2[0]['菌落总数数据表'] === 'A1,A2', JSON.stringify(outer2[0]['菌落总数数据表']));

  // 传了 loopFields 但未列出内层字段 → 也不展开
  const r3 = await buildPrintData(MOCK_TABLES.tblMain, '主表', [F_OUT, F_NO], 'r1',
    { loopFields: ['F_key微检市场需求表'] });
  assert('loopFields 未列出该字段 → 不展开',
    r3.data['F_key微检市场需求表'][0]['菌落总数数据表'] === 'A1,A2');

  // 模板里 {#X} 的 X 不是关联字段（如「引用/Lookup」）→ 显式提示，避免静默不展开
  const r4 = await buildPrintData(MOCK_TABLES.tblMain, '主表', [F_OUT, F_NO], 'r1',
    { loopFields: ['F_key微检市场需求表', '菌落总数数据表', '某引用字段'] });
  assert('非关联字段的循环给出提示',
    r4.warnings.some((x) => x.indexOf('某引用字段') >= 0 && x.indexOf('不是关联字段') >= 0),
    JSON.stringify(r4.warnings));
  assert('关联字段的循环不误报',
    !r4.warnings.some((x) => x.indexOf('「F_key微检市场需求表」不是关联字段') >= 0));

  // 页眉/正文里 {#.} 这类特殊写法不该被误报
  const r5 = await buildPrintData(MOCK_TABLES.tblMain, '主表', [F_OUT, F_NO], 'r1',
    { loopFields: ['F_key微检市场需求表', '菌落总数数据表', '.'] });
  assert('{#.} 不误报', !r5.warnings.some((x) => x.indexOf('「.」') >= 0));

  // ======================================================================
  // C) 复现线上「霉菌及酵母菌总数」列空白：规则没配「条件 + 不满足时输出」
  //    线上打印（测试.pdf）里：菌落总数列对 0 值的行显示 <10（规则有 fallback），
  //    霉菌列同样数据却整列空白（规则无条件、fallback 为空）。
  // ======================================================================
  console.log('\n[C] 循环内合并字段取不到值（线上空白复现）');
  if (tplPath) {
    const buf = fs.readFileSync(tplPath);
    const ab = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);

    // 子表数据：0 值的行 —— 数量=0、乘方留空（0 无法写成 m×10^n，表格里通常就留空）
    const rowWith = (name, n, pow, fn, fpow) => ({
      样品名称: name,
      细菌数量: n, 细菌乘方v2: pow,
      真菌数量: fn, 真菌乘方v2: fpow,
    });
    const data = {
      单号: 'NO-TEST',
      F_key微检市场需求表: [{
        菌落总数数据表: [
          rowWith('洗发水', '2.2', '3', '4', '2'),   // 有结果
          rowWith('叔酯乳液', '0', '', '0', ''),     // 未检出（数量=0、乘方留空）
          rowWith('苯丙乳液', '0', '', '0', ''),
        ],
      }],
    };
    const read = (field, scope) => {
      const v = scope && scope[field] != null ? scope[field] : data[field];
      return v == null || Array.isArray(v) ? '' : String(v);
    };
    const renderTable = async (rules) => {
      const warns = [];
      const z = new PizZip(await fillTemplate(ab, data, {
        resolve: makeMergeResolver(rules, read),
        warn: (m) => warns.push(m),
      }).arrayBuffer());
      return { rows: tableRows(z.file('word/document.xml').asText()), warns };
    };
    const findRow = (rows, name) => rows.find((r) => r.some((c) => c.includes(name)));
    const cell = (r, i) => (r && r[i] != null ? r[i] : '');

    // C1：线上现状 —— 细菌规则有「条件 + <10」，真菌规则无条件、fallback 为空
    const before = {
      '细菌数量|细菌乘方v2': {
        join: 'and', conditions: [{ field: '细菌数量', op: 'gt', value: '0' }],
        output: { mode: 'scientific', superscript: true, times: '×10', fallback: '<10' },
      },
      '真菌数量|真菌乘方v2': {
        join: 'and', conditions: [],
        output: { mode: 'scientific', superscript: true, times: '×10', fallback: '' },
      },
    };
    const c1 = await renderTable(before);
    const r1 = findRow(c1.rows, '叔酯乳液');
    assert('复现：0 值行 菌落列 = <10（规则配了 fallback）', cell(r1, 1) === '<10', JSON.stringify(r1));
    assert('复现：同一行 霉菌列 = 空白（规则无条件、fallback 为空）', cell(r1, 2) === '', JSON.stringify(r1));
    const s1 = findRow(c1.rows, '洗发水');
    assert('复现：有结果的行两列都正常', cell(s1, 1) === '2.2×10³' && cell(s1, 2) === '4×10²', JSON.stringify(s1));
    assert('诊断：给出「取不到值」提示（不再静默留白）',
      c1.warns.some((m) => m.includes('{{真菌数量}{真菌乘方v2}}') && m.includes('取不到值')),
      JSON.stringify(c1.warns));
    assert('诊断：只统计真正留白的明细行（2 行，不含外层分组行）',
      c1.warns.some((m) => m.includes('有 2 行')), JSON.stringify(c1.warns));
    assert('诊断：提示里给出改法（条件 / 条件不满足时输出）',
      c1.warns.some((m) => m.includes('条件不满足时输出')));
    assert('诊断：数据齐全的签名不误报',
      !c1.warns.some((m) => m.includes('细菌数量')));

    // C2：把真菌规则补成与细菌一致（条件 真菌数量>0 + 不满足输出 <10）
    const after = {
      ...before,
      '真菌数量|真菌乘方v2': {
        join: 'and', conditions: [{ field: '真菌数量', op: 'gt', value: '0' }],
        output: { mode: 'scientific', superscript: true, times: '×10', fallback: '<10' },
      },
    };
    const c2 = await renderTable(after);
    const r2 = findRow(c2.rows, '叔酯乳液');
    assert('修复后：0 值行 霉菌列也显示 <10', cell(r2, 2) === '<10', JSON.stringify(r2));
    const s2 = findRow(c2.rows, '洗发水');
    assert('修复后：有结果的行仍按科学计数法输出', cell(s2, 1) === '2.2×10³' && cell(s2, 2) === '4×10²', JSON.stringify(s2));
    assert('修复后：不再有「取不到值」提示',
      !c2.warns.some((m) => m.includes('取不到值')), JSON.stringify(c2.warns));
  }

  console.log(`\n结果：${fail === 0 ? '全部通过' : `${fail} 项失败`}（${pass} passed / ${fail} failed）`);
  process.exit(fail ? 1 : 0);
})().catch((e) => {
  console.error('异常：', e && (e.stack || e.message));
  process.exit(1);
});
