// 端到端验证：用真实模板 DM-RD-R-101 跑 xlsxFill，确认修复生效。
// 前置：esbuild 打包 src/services/xlsxFill.ts → .tmp_verify/xlsxFill.cjs
// 运行：node scripts/test-xlsx-record-form.cjs
const fs = require('fs');
const path = require('path');
const PizZip = require(path.resolve(__dirname, '..', 'node_modules', 'pizzip'));

const ROOT = path.resolve(__dirname, '..');
const BUNDLE = path.join(ROOT, '.tmp_verify', 'xlsxFill.cjs');
const TEMPLATE = process.env.XLSX_TEMPLATE || 'D:/下载/DM-RD-R-101 开发原始记录.xlsx';

if (!fs.existsSync(BUNDLE)) { console.error('缺少打包产物：' + BUNDLE); process.exit(1); }
if (!fs.existsSync(TEMPLATE)) { console.error('缺少模板：' + TEMPLATE); process.exit(1); }
const { fillXlsx } = require(BUNDLE);

function assert(cond, msg) {
  if (!cond) { console.error('FAIL: ' + msg); process.exitCode = 1; }
  else console.log('PASS: ' + msg);
}

function unesc(s) {
  return String(s).replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&apos;/g, "'").replace(/&amp;/g, '&');
}

// 取出 sheetData 中每行的 行号 + 纯文本
function rowsOf(sheetXml) {
  const sd = sheetXml.match(/<sheetData>([\s\S]*?)<\/sheetData>/);
  if (!sd) return [];
  const out = [];
  const rowRe = /<row r="(\d+)"[^>]*>([\s\S]*?)<\/row>/g;
  let m;
  while ((m = rowRe.exec(sd[1]))) {
    const text = unesc((m[2].match(/<t[^>]*>([\s\S]*?)<\/t>/g) || [])
      .map((x) => x.replace(/<t[^>]*>([\s\S]*?)<\/t>/, '$1')).join(' '));
    out.push({ r: parseInt(m[1], 10), text });
  }
  return out;
}

(async function main() {
  const src = fs.readFileSync(TEMPLATE);
  const ab = src.buffer.slice(src.byteOffset, src.byteOffset + src.byteLength);

  const data = {
    开发记录编号: 'RD-001',
    项目名称: '测试项目',
    实验时间: '2026-10-09',
    实验地点: '实验室',
    '温度（℃）': '25',
    '湿度（%）': '60',
    项目负责人: '张三',
    配方负责人: '李四',
    实验目的: '验证工艺可行性',
    配方名称: '配方A',
    小试工艺描述: '先加A搅拌30分钟，再加B',
    配方组成: [
      { 投料步骤: '1', 原料名: '原料甲', '配比（%）': '50' },
      { 投料步骤: '2', 原料名: '原料乙', '配比（%）': '30' },
      { 投料步骤: '3', 原料名: '原料丙', '配比（%）': '20' },
    ],
  };

  const blob = fillXlsx(ab, data);
  const outBuf = Buffer.from(await blob.arrayBuffer());
  const zip = new PizZip(outBuf);
  const sheetXml = zip.file('xl/worksheets/sheet1.xml').asText();
  const rows = rowsOf(sheetXml);
  const allText = rows.map((x) => x.text).join('\n');

  console.log('--- 输出行结构 ---');
  rows.forEach((x) => console.log('  行' + String(x.r).padStart(3) + ': ' + (x.text || '(空)').slice(0, 46)));

  console.log('\n--- 断言 ---');
  assert(!!zip.file('xl/worksheets/sheet1.xml'), '输出可被 PizZip 正常解析');

  // 1) 被删掉的三行必须回来（核心 BUG 修复）
  assert(allText.includes('小试工艺描述'), '「小试工艺描述」标签行已保留（修复前被整行删除）');
  assert(allText.includes('先加A搅拌30分钟，再加B'), '「小试工艺描述」占位符已被数据替换');
  assert(allText.includes('实验现象'), '「实验现象」标签行已保留（修复前被整行删除）');
  assert(allText.includes('稳定性试验'), '「稳定性试验」区块已保留');
  assert(allText.includes('试验条件'), '「试验条件」表头行已保留');

  // 2) @@PAGE 指令不再打印
  assert(!allText.includes('@@PAGE'), '分页指令不再作为正文打印');

  // 3) 明细行展开为 size=20 行
  const detailTexts = rows.filter((x) => x.text.includes('原料甲') || x.text.includes('原料乙') || x.text.includes('原料丙'));
  assert(detailTexts.length === 3, '三条明细数据各占一行（实际 ' + detailTexts.length + '）');
  assert(!allText.includes('{投料步骤}') && !allText.includes('{/配方组成}'), '明细循环标记已被清除');

  // 4) 行数与分页：size 是「上限」，只输出实际数据行（3 行），不补空白行
  //    专用指令行末尾删除后模板剩 23 行；before 11 行 + 明细 3 行 + after(行13..23) 11 行 = 25 行
  assert(rows.length === 25, '总行数 = 25（实际 ' + rows.length + '）');
  const maxRow = Math.max(...rows.map((x) => x.r));
  assert(maxRow === 25, '末行号 = 25 = before11 + 明细3 + after11（实际 ' + maxRow + '）');
  assert(!rows.some((x) => x.r > 25), '末尾无残留的空指令行');

  // 5) 顺序：明细 → 小试工艺描述 → 实验现象 → 稳定性试验 → 结论与签字
  const idx = (kw) => rows.find((x) => x.text.includes(kw))?.r ?? -1;
  const rDetail = Math.max(...detailTexts.map((x) => x.r));
  const rCraft = idx('小试工艺描述');
  const rPhen = idx('实验现象');
  const rStab = idx('稳定性试验');
  const rConc = idx('结论与签字');
  assert(rDetail < rCraft && rCraft < rPhen && rPhen < rStab && rStab < rConc,
    `区块顺序正确（明细末行${rDetail} < 工艺${rCraft} < 现象${rPhen} < 稳定性${rStab} < 结论${rConc}）`);

  // 6) ★ 本次修复核心：明细区之后不再补空白行，紧跟固定区块
  assert(rCraft === rDetail + 1, `明细区之后紧接「小试工艺描述」，无空白填充行（明细末行${rDetail} → 工艺行${rCraft}）`);
  const blankRows = rows.filter((x) => x.r > rDetail && x.r < rCraft).length;
  assert(blankRows === 0, '明细与固定区块之间无空行（实际 ' + blankRows + ' 行）');

  // 7) 表头与基本信息未被破坏
  assert(allText.includes('开发原始记录') && allText.includes('测试项目') && allText.includes('配方A'),
    '表头与基本信息字段正常填充');

  console.log(process.exitCode ? '\n存在失败用例' : '\n全部通过 ✅');
})();
