// 自测：附件「是否图片」的判定口径。
// 起因：线上出现「.jpeg 附件未插图、只打印了文件名」，需锁定判定分支是否正确。
// 前置：esbuild 打包 src/services/attachmentImages.ts 为 .tmp_verify/attachmentImages.cjs
// 运行：node scripts/test-attachment-detect.cjs
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const BUNDLE = path.join(ROOT, '.tmp_verify', 'attachmentImages.cjs');
if (!fs.existsSync(BUNDLE)) {
  console.error('缺少打包产物：' + BUNDLE);
  process.exit(1);
}
const { isImageAttachment } = require(BUNDLE);

function assert(cond, msg) {
  if (!cond) { console.error('FAIL: ' + msg); process.exitCode = 1; }
  else console.log('PASS: ' + msg);
}

// [附件, 期望是否图片, 说明]
const CASES = [
  [{ name: 'a.png', type: 'image/png' }, true, '标准 mime image/png'],
  [{ name: 'b.jpeg', type: 'image/jpeg' }, true, '标准 mime image/jpeg'],
  [{ name: 'bc0c9351f897958aae3b47fa194c8e7a.jpeg', type: 'image/jpeg' }, true, '用户实际场景（uuid 命名的 jpeg）'],
  [{ name: 'c.jpg', type: 'jpeg' }, true, 'type 只给裸扩展名 jpeg'],
  [{ name: 'd.jpg', type: 'jpg' }, true, 'type 只给裸扩展名 jpg'],
  [{ name: 'e.jpeg', type: 'application/octet-stream' }, true, '通用二进制 mime → 回退看文件名'],
  [{ name: 'f.jpeg', type: '' }, true, '未给 type → 回退看文件名'],
  [{ name: 'g.PNG', type: 'image/png' }, true, '大写扩展名'],
  [{ name: '合同扫描件.pdf', type: 'application/pdf' }, false, 'PDF 不是图片'],
  [{ name: 'h.pdf', type: 'application/octet-stream' }, false, '通用二进制 + 非图片扩展名'],
  [{ name: 'i.png', type: 'application/pdf' }, false, 'type 明确非图片时不因文件名误判'],
  [{ name: '检测报告.docx', type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' }, false, 'docx 不是图片'],
];

console.log('附件图片判定口径：');
CASES.forEach(([att, want, desc]) => {
  const got = isImageAttachment(att);
  assert(got === want, `${desc} → ${got}（期望 ${want}）`);
});

console.log(process.exitCode ? '\n存在失败用例' : '\n全部通过 ✅');
