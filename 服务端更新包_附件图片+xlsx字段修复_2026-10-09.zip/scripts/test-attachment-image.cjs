// 自测：附件图片注入（真实模块端到端）。
// 前置：先由 esbuild 把 src/services/docxFill.ts 打包为 .tmp_verify/docxFill.cjs
// 运行：node scripts/test-attachment-image.cjs
const fs = require('fs');
const path = require('path');
const PizZip = require(path.resolve(__dirname, '..', 'node_modules', 'pizzip'));
const Docxtemplater = require(path.resolve(__dirname, '..', 'node_modules', 'docxtemplater')).default;

const ROOT = path.resolve(__dirname, '..');
const BUNDLE = path.join(ROOT, '.tmp_verify', 'docxFill.cjs');
if (!fs.existsSync(BUNDLE)) {
  console.error('缺少打包产物：' + BUNDLE + '\n请先用 esbuild 打包 src/services/docxFill.ts');
  process.exit(1);
}
const { fillTemplate } = require(BUNDLE);

function assert(cond, msg) {
  if (!cond) { console.error('FAIL: ' + msg); process.exitCode = 1; }
  else console.log('PASS: ' + msg);
}

const W_NS = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
const R_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
const CT_NS = 'http://schemas.openxmlformats.org/package/2006/content-types';
const SENTINEL = '\uE000ATT';

// 构造最小可用 docx：正文一段 "图：{附件} 完"（末尾带格式，验证格式保留）
function buildMinimalDocx() {
  const zip = new PizZip();
  zip.file('[Content_Types].xml',
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    `<Types xmlns="${CT_NS}">` +
    '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' +
    '<Default Extension="xml" ContentType="application/xml"/>' +
    '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>' +
    '</Types>');
  zip.file('_rels/.rels',
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
    `<Relationship Id="rId1" Type="${R_NS}/officeDocument" Target="word/document.xml"/>` +
    '</Relationships>');
  zip.file('word/_rels/document.xml.rels',
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"></Relationships>');
  zip.file('word/document.xml',
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    `<w:document xmlns:w="${W_NS}" xmlns:r="${R_NS}"><w:body>` +
    '<w:p><w:r><w:rPr><w:b/></w:rPr><w:t xml:space="preserve">图：{附件} 完</w:t></w:r></w:p>' +
    '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/></w:sectPr>' +
    '</w:body></w:document>');
  return zip.generate({ type: 'nodebuffer' });
}

function toBuf(blobOrBuf) {
  if (Buffer.isBuffer(blobOrBuf)) return blobOrBuf;
  if (blobOrBuf && typeof blobOrBuf.arrayBuffer === 'function') {
    return blobOrBuf.arrayBuffer().then((ab) => Buffer.from(ab));
  }
  throw new Error('无法识别的输出类型');
}

function readDocXml(buf) {
  return new PizZip(buf).file('word/document.xml').asText();
}

(async function main() {
  const pngPath = path.join(ROOT, 'scripts', 'test-stamp.png');
  assert(fs.existsSync(pngPath), '测试用 PNG 存在: scripts/test-stamp.png');
  const pngBase64 = fs.readFileSync(pngPath).toString('base64');

  const templateBuf = buildMinimalDocx();
  assert(templateBuf.length > 0, '构造最小模板 docx 成功 (' + templateBuf.length + ' bytes)');

  // ============ 用例 1：图片附件 → inline 图片 ============
  const bind1 = {
    byField: {
      附件: { parts: [{ kind: 'image', base64: pngBase64, ext: 'png', w: 200, h: 100 }], widthCm: 4 },
    },
  };
  const out1 = await toBuf(fillTemplate(templateBuf.buffer.slice(0), { 附件: 'x.png' }, undefined, bind1));
  const zip1 = new PizZip(out1);
  const xml1 = zip1.file('word/document.xml').asText();
  const rels1 = zip1.file('word/_rels/document.xml.rels').asText();
  const ct1 = zip1.file('[Content_Types].xml').asText();

  assert(!!zip1.file('word/media/attach_document_1.png'), '媒体文件已写入 word/media/attach_document_1.png');
  assert(xml1.indexOf('<w:drawing>') >= 0 && xml1.indexOf('<wp:inline') >= 0, 'document.xml 含 inline drawing');
  assert(/r:embed="rIdAttachdocument1"/.test(xml1), 'drawing 引用了正确的 rId');
  assert(xml1.indexOf(SENTINEL) < 0, '渲染后无残留哨兵字符');
  assert(xml1.indexOf('图：') >= 0 && xml1.indexOf(' 完') >= 0, '占位符前后文本被保留');
  assert(/<w:rPr><w:b\/><\/w:rPr>/.test(xml1), '原 run 的字符格式（加粗）被保留');
  assert(/Relationship Id="rIdAttachdocument1"[\s\S]*?Target="media\/attach_document_1\.png"/.test(rels1), 'rels 已登记图片关系');
  assert(ct1.indexOf('Extension="png"') >= 0, '[Content_Types].xml 已补 png 声明');

  // 宽度换算：4cm = 1440000 EMU；高 = 宽 * (100/200) = 720000
  assert(xml1.indexOf('<wp:extent cx="1440000" cy="720000"/>') >= 0, '图片尺寸按宽度 4cm 等比换算正确');

  // XML 合法性：用 docxtemplater 重新解析（畸形 XML 会抛错）
  let reparsed = true;
  try {
    const d = new Docxtemplater(new PizZip(out1), { paragraphLoop: true });
    d.render({});
  } catch (e) {
    reparsed = false;
    console.error('   重新解析报错: ' + e.message);
  }
  assert(reparsed, '注入图片后的 docx 可被 docxtemplater 正常解析（XML 合法）');

  // ============ 用例 2：非图片附件 → 保持文件名文本 ============
  const out2 = await toBuf(fillTemplate(templateBuf.buffer.slice(0), { 附件: '合同扫描件.pdf' }, undefined, undefined));
  const xml2 = readDocXml(out2);
  assert(xml2.indexOf('合同扫描件.pdf') >= 0, '非图片附件仍输出文件名文本');
  assert(xml2.indexOf('<w:drawing>') < 0, '非图片附件不产生图片');
  assert(xml2.indexOf(SENTINEL) < 0, '非图片附件无哨兵残留');

  // ============ 用例 3：混合（先文件后图片）→ 顺序与内容都保留 ============
  const bind3 = {
    byField: {
      附件: {
        parts: [
          { kind: 'text', text: '说明.pdf' },
          { kind: 'image', base64: pngBase64, ext: 'png', w: 200, h: 100 },
        ],
        widthCm: 2,
      },
    },
  };
  const out3 = await toBuf(fillTemplate(templateBuf.buffer.slice(0), { 附件: '' }, undefined, bind3));
  const xml3 = readDocXml(out3);
  const posText = xml3.indexOf('说明.pdf');
  const posImg = xml3.indexOf('<w:drawing>');
  assert(posText >= 0 && posImg >= 0, '混合附件同时产出文件名文本与图片');
  assert(posText < posImg, '混合附件保持原始顺序（文件在前、图片在后）');
  assert(xml3.indexOf('<wp:extent cx="720000"') >= 0, '宽度 2cm 生效（720000 EMU）');

  // ============ 用例 4：@@PAGE 多页 + 附件图片（验证多页合并时媒体不丢） ============
  function buildPagedDocx() {
    const zip = new PizZip();
    zip.file('[Content_Types].xml',
      '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
      `<Types xmlns="${CT_NS}">` +
      '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' +
      '<Default Extension="xml" ContentType="application/xml"/>' +
      '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>' +
      '</Types>');
    zip.file('_rels/.rels',
      '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
      '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
      `<Relationship Id="rId1" Type="${R_NS}/officeDocument" Target="word/document.xml"/>` +
      '</Relationships>');
    zip.file('word/_rels/document.xml.rels',
      '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
      '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"></Relationships>');
    zip.file('word/document.xml',
      '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
      `<w:document xmlns:w="${W_NS}" xmlns:r="${R_NS}"><w:body>` +
      '<w:p><w:r><w:t>@@PAGE field=明细 size=3 sum=数量:合计数量 @@</w:t></w:r></w:p>' +
      '<w:p><w:r><w:t xml:space="preserve">图：{附件}</w:t></w:r></w:p>' +
      '<w:p><w:r><w:t>{#明细}{名称}|{/明细}</w:t></w:r></w:p>' +
      '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/></w:sectPr>' +
      '</w:body></w:document>');
    return zip.generate({ type: 'nodebuffer' });
  }

  const rows = Array.from({ length: 6 }, (_, i) => ({ 名称: 'N' + (i + 1), 数量: '2' }));
  const bind4 = {
    byField: {
      附件: { parts: [{ kind: 'image', base64: pngBase64, ext: 'png', w: 200, h: 100 }], widthCm: 3 },
    },
  };
  const pagedBuf = buildPagedDocx();
  const out4 = await toBuf(fillTemplate(pagedBuf.buffer.slice(0), { 附件: 'x.png', 明细: rows }, undefined, bind4));
  const zip4 = new PizZip(out4);
  const xml4 = zip4.file('word/document.xml').asText();
  const rels4 = zip4.file('word/_rels/document.xml.rels').asText();
  const media4 = Object.keys(zip4.files).filter((n) => /^word\/media\/attach_/.test(n));

  assert((xml4.match(/<w:drawing>/g) || []).length === 2, '两页各插入一张图片（共 2 个 drawing）');
  assert(xml4.indexOf('<w:br w:type="page"/>') >= 0, '多页之间插入了分页符');
  assert(media4.length >= 2, '第 2 页的图片媒体已合并进最终 docx（实际 ' + media4.length + ' 个）');
  const embeds = [...xml4.matchAll(/r:embed="([^"]+)"/g)].map((m) => m[1]);
  assert(embeds.length === 2, '两处 r:embed 引用');
  assert(embeds.every((id) => rels4.indexOf(`Id="${id}"`) >= 0), '所有图片引用都能在 rels 中找到对应关系（无悬空引用）');
  assert(xml4.indexOf(SENTINEL) < 0, '多页渲染后无残留哨兵');
  assert(xml4.indexOf('@@PAGE') < 0, '分页指令行已被剔除（不打印）');

  let reparsed4 = true;
  try { new Docxtemplater(new PizZip(out4), { paragraphLoop: true }).render({}); }
  catch (e) { reparsed4 = false; console.error('   重新解析报错: ' + e.message); }
  assert(reparsed4, '多页 + 图片的 docx XML 合法');

  console.log(process.exitCode ? '\n存在失败用例' : '\n全部通过 ✅');
})();
